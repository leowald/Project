import "./ListItem.css";

function ListItem(props) {
  return <div className="listItem">{props.name}</div>;
}

export default ListItem;

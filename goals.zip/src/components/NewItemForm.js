import "./NewItemForm.css";
import React, { useState } from "react";

function NewItemForm(props) {
  const [newGoal, setGoal] = useState("");
  const [validInput, setValidInput] = useState(true);

  function recordInput(event) {
    if (event.target.value.trim().length > 0) {
      setValidInput(true);
    }
    setGoal(event.target.value);
  }

  function addGoal(event) {
    event.preventDefault();

    if (newGoal.trim().length > 0) {
      props.onNewItem(newGoal);
      //setValidInput(true);
    } else {
      setValidInput(false);
    }

    setGoal("");
  }

  return (
    <form onSubmit={addGoal}>
      <div className="form_item">
        <label></label>
        <input
          class={!validInput ? "error" : ""}
          value={newGoal}
          onChange={recordInput}
          type="text"
        ></input>
        {!validInput ? <p class="red">Invalid Input</p> : ""}
      </div>
      <button type="submit">ADD GOAL</button>
    </form>
  );
}

export default NewItemForm;
